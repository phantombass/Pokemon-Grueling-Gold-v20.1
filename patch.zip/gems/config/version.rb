module PokeApi
  VERSION = '0.1.1'.freeze
end
