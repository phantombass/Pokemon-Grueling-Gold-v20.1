# frozen_string_literal: true

class Logger
  VERSION = "1.5.0"
end
