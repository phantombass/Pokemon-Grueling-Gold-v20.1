# frozen_string_literal: true

require 'digest/sha2.so'
